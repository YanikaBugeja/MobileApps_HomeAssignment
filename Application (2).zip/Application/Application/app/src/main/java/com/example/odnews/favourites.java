package com.example.odnews;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class favourites extends AppCompatActivity {
    private EditText fName;
    private EditText lName;
    private EditText occupation;
    private TextView result;

    public String nameString;
    public String surnameString;
    public String occupationString;


    @Override
    public void onStop()
    {
        super.onStop();
        SharedPreferences sharedPrefs = getSharedPreferences("info", MODE_PRIVATE);
        SharedPreferences.Editor nameEditor = sharedPrefs.edit();
        nameEditor.putString("name", fName.getText().toString());
        nameEditor.putString("surname", lName.getText().toString());
        nameEditor.putString("occupation", occupation.getText().toString());
        nameEditor.commit();
    }

    @Override
    public void onPause()
    {
        super.onPause();
        SharedPreferences sharedPrefs = getSharedPreferences("info", MODE_PRIVATE);
        SharedPreferences.Editor nameEditor = sharedPrefs.edit();
        nameEditor.putString("name", fName.getText().toString());
        nameEditor.putString("surname", lName.getText().toString());
        nameEditor.putString("occupation", occupation.getText().toString());
        nameEditor.commit();
    }

    @Override
    public void onStart()
    {
        super.onStart();
        SharedPreferences sharedPrefs = getSharedPreferences("info", MODE_PRIVATE);
        nameString = sharedPrefs.getString("name", "");
        surnameString = sharedPrefs.getString("surname", "");
        occupationString = sharedPrefs.getString("occupation", "");
        result.setText("Current User: "+ nameString+" "+surnameString/*+", you are a/an "+occupationString*/);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        SharedPreferences sharedPrefs = getSharedPreferences("info", MODE_PRIVATE);
        nameString = sharedPrefs.getString("name", "");
        surnameString = sharedPrefs.getString("surname", "");
        occupationString = sharedPrefs.getString("occupation", "");
        result.setText("Current User: "+ nameString+" "+surnameString+", you are a/an "+occupationString);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fName = (EditText) findViewById(R.id.eT_name);
        lName = (EditText) findViewById(R.id.eT_surname);
        occupation = (EditText) findViewById(R.id.eT_occupation);
        result = (TextView) findViewById(R.id.txt_savedData);
    }

}
