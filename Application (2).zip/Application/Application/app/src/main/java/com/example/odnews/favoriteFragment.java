package com.example.odnews;

import android.content.SharedPreferences;
import android.icu.util.Output;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static android.content.Context.MODE_PRIVATE;

public class favoriteFragment extends Fragment {

    private EditText fName;
    private EditText lName;
    private EditText occupation;
    private TextView result;

    public String nameString;
    public String surnameString;
    public String occupationString;


    @Override
    public void onStop()
    {
        super.onStop();
        SharedPreferences sharedPrefs = this.getActivity().getSharedPreferences("info", MODE_PRIVATE);
        SharedPreferences.Editor nameEditor = sharedPrefs.edit();
        nameEditor.putString("name", fName.getText().toString());
        nameEditor.putString("surname", lName.getText().toString());
        nameEditor.putString("occupation", occupation.getText().toString());
        nameEditor.commit();
    }

    @Override
    public void onPause()
    {
        super.onPause();
        SharedPreferences sharedPrefs = this.getActivity().getSharedPreferences("info", MODE_PRIVATE);
        SharedPreferences.Editor nameEditor = sharedPrefs.edit();
        nameEditor.putString("name", fName.getText().toString());
        nameEditor.putString("surname", lName.getText().toString());
        nameEditor.putString("occupation", occupation.getText().toString());
        nameEditor.commit();
    }

    @Override
    public void onStart()
    {
        super.onStart();
        SharedPreferences sharedPrefs = this.getActivity().getSharedPreferences("info", MODE_PRIVATE);
        nameString = sharedPrefs.getString("name", "");
        surnameString = sharedPrefs.getString("surname", "");
        occupationString = sharedPrefs.getString("occupation", "");
        result.setText("Current User: "+ nameString+" "+surnameString/*+", you are a/an "+occupationString*/);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        SharedPreferences sharedPrefs = this.getActivity().getSharedPreferences("info", MODE_PRIVATE);
        nameString = sharedPrefs.getString("name", "");
        surnameString = sharedPrefs.getString("surname", "");
        occupationString = sharedPrefs.getString("occupation", "");
        result.setText("Current User: "+ nameString+" "+surnameString+", you are a/an "+occupationString);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        RelativeLayout rl = (RelativeLayout) inflater.inflate(R.layout.fragement_favorite, null);


        fName = (EditText) this.getActivity().findViewById(R.id.eT_name);
        lName = (EditText) this.getActivity().findViewById(R.id.eT_surname);
        occupation = (EditText) this.getActivity().findViewById(R.id.eT_occupation);
        result = (TextView) this.getActivity().findViewById(R.id.txt_savedData);

        return rl;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }
}
