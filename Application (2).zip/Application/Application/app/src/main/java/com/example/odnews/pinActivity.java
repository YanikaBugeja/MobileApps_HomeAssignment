package com.example.odnews;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.andrognito.pinlockview.IndicatorDots;
import com.andrognito.pinlockview.PinLockListener;
import com.andrognito.pinlockview.PinLockView;

import java.text.DateFormat;
import java.util.Calendar;

public class pinActivity extends AppCompatActivity {

    private PinLockView mPinLockView;
    private IndicatorDots mIndicatorDots;
    private final static String TAG = pinActivity.class.getSimpleName();
    private final static String TRUE_CODE = "123456";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);
        Button prev = (Button)findViewById(R.id.printButton);
        prev.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent i = new Intent(pinActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        mPinLockView = (PinLockView) findViewById(R.id.pin_lock_view);
        mIndicatorDots = (IndicatorDots) findViewById(R.id.indicator_dots);

        //attach lock view with dot indicator
        mPinLockView.attachIndicatorDots(mIndicatorDots);

        //set lock code length
        mPinLockView.setPinLength(6);

        //set listener for lock code change
        mPinLockView.setPinLockListener(new PinLockListener() {
            @Override
            public void onComplete(String pin) {
                Log.d(TAG, "PIN Code: " + pin);

                //User input true code
                if (pin.equals(TRUE_CODE)) {
                    Intent intent = new Intent(pinActivity.this, applicationApi.class);
                    intent.putExtra("code", pin);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(pinActivity.this, "Incorrect PIN, Try Again!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onEmpty() {
                Log.d(TAG, "PIN Code is Empty!");
            }

            @Override
            public void onPinChange(int pinLength, String intermediatePin) {
                Log.d(TAG, "PIN Changed, New Length " + pinLength + " With Intermidiate PIN " + intermediatePin);
            }
        });
    }



    @Override
    protected void onPause(){
        super.onPause();


        SharedPreferences sharedPreferences = getSharedPreferences("date", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("date",String.valueOf(Calendar.getInstance().getTime()));

        editor.commit();


    }



    @Override
    protected void onStop(){
        super.onStop();

        SharedPreferences sharedPreferences = getSharedPreferences("date", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("date",String.valueOf(Calendar.getInstance().getTime()));
        editor.commit();

    }

    @Override
    protected void onStart(){
        super.onStart();
        SharedPreferences sharedPreferences = getSharedPreferences("date", Context.MODE_PRIVATE);
        String text = sharedPreferences.getString("hello", "");

        String date = sharedPreferences.getString("date", "");
        Snackbar snackbar = Snackbar.make(findViewById(R.id.drawer_layout), date, Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        SharedPreferences sharedPreferences = getSharedPreferences("date", Context.MODE_PRIVATE);
        String text = sharedPreferences.getString("hello", "");

        String date = sharedPreferences.getString("date", "");
        Snackbar snackbar = Snackbar.make(findViewById(R.id.drawer_layout), date, Snackbar.LENGTH_LONG);
        snackbar.show();
    }
}